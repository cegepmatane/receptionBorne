## read-json

Reads and parses a JSON file.

## Install

```bash
$ npm install read-json
```

## Usage

```js
readJSON('./package.json', function(error, manifest){

    manifest.name
    // => 'read-json'

})
```

![](https://dl.dropbox.com/s/9q2p5mrqnajys22/npmel.jpg)
